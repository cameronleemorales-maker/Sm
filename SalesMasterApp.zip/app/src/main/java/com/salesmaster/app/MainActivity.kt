package com.salesmaster.app

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.salesmaster.app.databinding.ActivityMainBinding
import android.content.Intent
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val client = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnTraining.setOnClickListener {
            startActivity(Intent(this, TrainingActivity::class.java))
        }
        binding.btnProfile.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }

        binding.btnRespond.setOnClickListener {
            val objection = binding.inputObjection.text?.toString()?.trim().orEmpty()
            if (objection.isEmpty()) {
                binding.outputResponse.text = "Type what the customer said first."
            } else {
                fetchRebuttal(objection)
            }
        }
    }

    private fun fetchRebuttal(objection: String) {
        val key = OpenAIKeyStore.getKey(this)

        if (key.isNullOrBlank()) {
            // Offline fallback so the app runs without a key
            binding.outputResponse.text = "AI (offline demo): Try acknowledging the concern, ask a clarifying question, then show a concise benefit tied to their goal."
            return
        }

        binding.outputResponse.text = "Thinking..."

        val prompt = "Customer says: \"" + objection + "\"\nDraft a short, friendly sales rebuttal (2-3 sentences)."

        val body = JSONObject().apply {
            put("model", "gpt-4o-mini")
            put("messages", org.json.JSONArray().put(
                JSONObject().put("role","user").put("content",prompt)
            ))
            put("temperature", 0.7)
        }

        val request = Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .addHeader("Authorization", "Bearer $key")
            .addHeader("Content-Type", "application/json")
            .post(RequestBody.create(MediaType.get("application/json"), body.toString()))
            .build()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                client.newCall(request).execute().use { resp ->
                    val out = if (resp.isSuccessful) {
                        val json = JSONObject(resp.body()!!.string())
                        val msg = json.getJSONArray("choices")
                            .getJSONObject(0)
                            .getJSONObject("message")
                            .getString("content")
                        msg.trim()
                    } else {
                        "OpenAI error: " + resp.code()
                    }
                    withContext(Dispatchers.Main) {
                        binding.outputResponse.text = out
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    binding.outputResponse.text = "Network error: ${e.message}"
                }
            }
        }
    }
}