package com.salesmaster.app

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.salesmaster.app.databinding.ActivityTrainingBinding

class TrainingActivity : AppCompatActivity() {
    private lateinit var binding: ActivityTrainingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTrainingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.trainingBody.text = """
            • Price: "It sounds like budget is important. If we can show a clear ROI within 30 days, would that make the price feel better?"
            • Timing: "Totally fair—when is a better time to revisit so you benefit before the busy season hits?"
            • Competitor: "Good choice—what do you like most there? Maybe we can match that and add X."
        """.trimIndent()
    }
}